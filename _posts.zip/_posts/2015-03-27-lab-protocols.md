---
layout: post
title: "Lab Protocols"
category: post
date: 2015-03-27 22:01:06
thumbnail: https://farm1.staticflickr.com/1/3934032_d7262dd389_q.jpg
tags:
- protocols
---

####Dental cement, C&B-Metabond Adhesive Cement, Parkell Inc
- S396 (3g) Radiopaque Tooth-Shade L-Powder
- S398 (10ml) C&B-Metabond Quick Base (blue)
- S371 (0.7ml) Catalyst Gold Label

4 drops Quick Base + 1 drop Catalyst + 2 scoops Powder
