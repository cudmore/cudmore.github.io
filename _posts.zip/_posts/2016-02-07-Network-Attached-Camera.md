---
layout: post
title: "Network attached camera"
category: post
date: 2016-02-07 22:01:06
tags:
- raspberry
- linux
- flask
---

- camera

  DLink DCS-930L

- On the network

  F0:7D:68:03:60:B8
  192.168.1.12

  pw: admin
  pass: <blank> as in none

- get an image

  http://192.168.1.12/image/jpeg.cgi